package co.edu.upb.proyecto.datastructures.model.stack;

public interface Stack<E> {
    /**
   * Allows you to retrieve the value at the top of a stack without actually
   * removing it.
   * 
   * @return the value at the top of the stack.
   */
  public E peek();

  /**
   * Removes the value at the top of the stack and returns it.
   * 
   * @return the value at the top of the stack.
   */
  public E pop();

  /**
   * Adds a value to the top of the stack.
   * 
   * @param element the value to add to the top of the stack.
   * @return true if the value was added to the stack, false otherwise.
   */
  public boolean push(E element);
}
