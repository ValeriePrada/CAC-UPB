package co.edu.upb.proyecto.model;

import java.io.Serializable;
import java.util.Date;

/**
 * clase que representa a un cliente dentro del sistema
 * 
 * hereda de la clase Usuario, por lo que también tiene
 * información relacionada con autenticación y roles
 * 
 * esta clase almacena información personal del cliente,
 * como nombre, correo, teléfono, edad, membresia premium,
 * estado de actividad, cédula y fecha de nacimiento
 * 
 * tambien implementa Serializable para permitir que
 * los objetos puedan guardarse en archivos
*/
public class Cliente extends Usuario implements Serializable{

    /**
     * nombre del cliente
    */
    private String nombre;

    /**
     * correo electronico del cliente
    */
    private String email;

    /**
     * numero de celular del cliente
    */
    private String telefono;

    /**
     * edad del cliente
    */
    private int edad;

    /**
     * indica si el cliente tiene membresia premium
    */
    private boolean premium;

    /**
     * estado del cliente dentro en el sistema
     * true = activo
     * false = inactivo
    */
    private boolean estado;

    /**
     * documento de identidad del cliente
    */
    private String cedula;

    /**
     * fecha de nacimiento del cliente
    */
    private Date fechaNacimiento;

    /**
     * constructor encargado de inicializar un cliente
     * con su información basica y de autenticación
     * 
     * también llama al constructor de la clase Usuario
     * para inicializar los atributos heredados
     * 
     * @param id identificador del cliente
     * @param username nombre de usuario
     * @param password contraseña del usuario
     * @param nombre nombre completo del cliente
     * @param email correo electrónico
     * @param telefono número de teléfono
     * @param edad edad del cliente
     * @param premium define si el cliente es premium
     * @param estado estado del cliente
    */
    public Cliente(int id, String username, String password, String nombre, String email, String telefono, int edad, boolean premium, boolean estado) {

        super(id, username, password, Rol.CLIENTE, edad, premium);
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.edad = edad;
        this.premium = premium;
        this.estado = estado;
    }


    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefono() {
        return telefono;
    }

    public int getEdad() {
        return edad;
    }

    public boolean isPremium() {
        return premium;
    }

    public boolean isActivo() {
        return estado;
    }

    public String getCedula() {
        return cedula;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            this.nombre = nombre;
        }
    }

    public void setEmail(String email) {
        if (email != null && email.contains("@")) {
            this.email = email;
        }
    }

    public void setTelefono(String telefono) {
        if (telefono != null && !telefono.trim().isEmpty()) {
            this.telefono = telefono;
        }
    }

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;
        }
    }

    public void setPremium(boolean premium) {
        this.premium = premium;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * verifica si la información principal del cliente
     * cumple con las validaciones básicas del sistema.
     * 
     * se valida que
     * - El nombre no esté vacio
     * - El correo contenga el carácter '@'
     * - La edad sea valida
     * 
     * @return true si los datos son válidos y false en caso contrario
    */
    public boolean esValido() {
        return nombre != null && !nombre.isEmpty()
            && email != null && email.contains("@")
            && edad >= 0;
    }

    /**
     * retorna una representación textual del objeto Cliente
     * 
     * este método facilita mostrar información del cliente
     * en consola como los reportes
     * 
     * @return cadena con la información del cliente
    */
    public String toString() {
        return "Cliente{" +
                "id=" + getId() +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", edad=" + edad +
                ", premium=" + premium +
                ", activo=" + estado +
                '}';
    }
}
