package co.edu.upb.proyecto.model;

/**
 * Clase que representa un turno en proceso de atención
 * 
 * Relaciona un ticket, un banco y un estado de atención
*/
public class Turno {

    /**
     * Identificador del turno
    */
    private int idTurno;

    /**
     * Ticket asociado al turno
    */
    private Ticket ticket;

    /**
     * Banco donde será atendido el cliente
    */
    private Banco banco;

    /**
     * Estado actual del turno
    */
    private EstadoTurno estado;

    /**
     * Constructor que inicializa el turno con su información
     * 
     * @param idTurno Identificador del turno
     * @param ticket Ticket asociado
     * @param banco Banco asignado
     * @param estado Estado actual del turno
    */
    public Turno(int idTurno, Ticket ticket, Banco banco, EstadoTurno estado) {
        this.idTurno = idTurno;
        this.ticket = ticket;
        this.banco = banco;
        this.estado = estado;
    }

    public int getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(int idTurno) {
        this.idTurno = idTurno;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    public Banco getBanco() {
        return banco;
    }

    public void setBanco(Banco banco) {
        this.banco = banco;
    }

    public EstadoTurno getEstado() {
        return estado;
    }

    public void setEstado(EstadoTurno estado) {
        this.estado = estado;
    }

    /**
     * Asigna un banco al turno
     * 
     * @param banco Banco que atenderá el turno
    */
    public void asignarBanco(Banco banco) {
        this.banco = banco;
    }

    /**
     * Cambia el estado del turno a LLAMADO, indicando que el cliente debe acercarse
    */
    public void llamar() {
        this.estado = EstadoTurno.LLAMADO;
    }

    /**
     * Cambia el estado del turno a EN_ATENCION, indicando que el cliente está siendo atendido
    */
    public void iniciarAtencion() {
        this.estado = EstadoTurno.EN_ATENCION;
    }

    /**
     * Cambia el estado del turno a FINALIZADO, indicando que el proceso terminó
    */
    public void finalizar() {
        this.estado = EstadoTurno.FINALIZADO;
    }
}
