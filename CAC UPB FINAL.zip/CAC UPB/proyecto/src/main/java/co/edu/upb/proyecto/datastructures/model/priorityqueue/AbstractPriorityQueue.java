package co.edu.upb.proyecto.datastructures.model.priorityqueue;

import co.edu.upb.proyecto.datastructures.model.collection.AbstractCollection;

public abstract class AbstractPriorityQueue<E> extends AbstractCollection<E> implements PriorityQueue<E>{

}
