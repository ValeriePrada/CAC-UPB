package co.edu.upb.proyecto.datastructures.model.queue;

public interface Queue<E> {

    public E peek();

    public E extract();

    public boolean insert(E element);

}
