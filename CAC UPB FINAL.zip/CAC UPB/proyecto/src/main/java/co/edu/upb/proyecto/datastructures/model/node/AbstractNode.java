package co.edu.upb.proyecto.datastructures.model.node;

/**
 * An abstract implementation of the Node interface.
 * Provides common functionality for nodes in a data structure.
 *
 * @param <E> the type of element stored in the node.
 */
public abstract class AbstractNode<E> implements Node<E>, Cloneable { //permite clonar ese objeto, crear otro objeto nuevo con otra dirección de memoria, lo permite la interfaz CLONEABLE

    protected E element;

  /**
   * Constructs an AbstractNode with a null element.
   */
    protected AbstractNode() {
        this.element = null; //no tiene objeto, por eso es NULL
    }

    /**
     * Constructs an AbstractNode with the specified element.
     *
     * @param element the element to be stored in the node.
     */
    protected AbstractNode(E element) {
        this.element = element;
    }

    @Override
    public void set(E element) {
        this.element = element;
    }

    @Override
    public E get() {
        return this.element;
    }

    @Override
    public String toString() { 
        return element.toString(); 
    }
}
